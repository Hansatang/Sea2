import javafx.application.Application;

public class StudentFileAdapterGUI4Test
{
  /**
   * Starts the program
   * @param args Command line arguments
   */
  public static void main(String[] args)
  {
    Application.launch(StudentFileAdapterGUI4.class);
  }
}
